"""Validate all default-sized 27B campaigns, preserving source boundaries."""

import hashlib
import json
import statistics
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent
commits = {
    "original": "32fdd92c880a8fc1341e37e604c8a568ef558ebb",
    "first-shutdown-fix": "2a30a17d2bf5310cc432cf60f9243a7422c3668d",
    "final": "9d72bb8fcb34cf5357f38757e832f07c81acb21d",
}
method = "7ff73a02c9c3b790a70d127cbbf996dfa8d24592e5b6b6d3be155313392d34e7"
assert (
    hashlib.sha256((root / "benchmark_default_prefill.py").read_bytes()).hexdigest()
    == method
)
fields = {
    "short_ttft_ms": ("short", "ttft_ms"),
    "short_solo_ttft_ms": ("short_solo", "ttft_ms"),
    "long_total_ms": ("long", "total_ms"),
    "long_solo_total_ms": ("long_solo", "total_ms"),
}
for case, candidate in commits.items():
    path = root / case / "27b-2048/default-routes-final/results.json"
    d = json.loads(path.read_text())
    assert d["model_revision"] == "c000ac2c2057d94be3fa931000c31723aac53282"
    assert d["complete"] and len(d["rows"]) == 8 and len(d["arms"]) == 4
    assert (
        d["repeat"] == d["cycles"] == 2
        and d["harness_sha256"] == d["_methodology_hash"] == method
    )
    assert [(a["label"], a["source_commit"]) for a in d["arms"]] == [
        (
            f"cycle{cycle}-{kind}2048",
            "bec47abba980d48432c8b5917ca682dd0a5758de"
            if kind == "baseline"
            else candidate,
        )
        for cycle in (0, 1)
        for kind in (
            ("baseline", "candidate") if cycle == 0 else ("candidate", "baseline")
        )
    ]
    subprocess.run(
        [sys.executable, str(root / "validate_matrix_cell.py"), str(path), "8"],
        check=True,
    )
    for kind in ("baseline", "candidate"):
        medians = {
            key: statistics.median(
                r[which][metric] for r in d["rows"] if r["arm"] == kind + "2048"
            )
            for key, (which, metric) in fields.items()
        }
        assert medians == d["summary"][kind + "2048"]["retrieval"]
    b = d["summary"]["baseline2048"]["retrieval"]
    c = d["summary"]["candidate2048"]["retrieval"]
    delta = {key: (c[key] / b[key] - 1) * 100 for key in fields}
    assert delta["short_ttft_ms"] <= -30
    assert all(delta[k] <= 10 for k in fields if k != "short_ttft_ms")
    model = json.loads((root / case / "model-manifest.json").read_text())[
        "c000ac2c2057d94be3fa931000c31723aac53282"
    ]
    if case == "original":
        reference = model
    else:
        assert model == reference
    print(
        case,
        "passed exact source/method/model binding, raw medians, HTTP and cache/cancel lifecycle; changes%",
        json.dumps(delta, sort_keys=True),
    )
for name, entry in json.loads((root / "manifest.json").read_text()).items():
    raw = (root / name).read_bytes()
    assert (
        len(raw) == entry["bytes"]
        and hashlib.sha256(raw).hexdigest() == entry["sha256"]
    ), name
print("All inner artifact hashes passed")
