"""Validate frozen HTTP A/B controls without asserting an off-path speedup."""

import hashlib
import json
import statistics
import subprocess
import sys
from pathlib import Path

from benchmark_default_prefill import validate_cold, validate_overlap

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent
cases = {
    "gemma4-2048": ("0d77464eeb233a2da68ebf9d7dc4edaac7db956d", "mllm"),
    "nemotron-2048": ("55ac8c89261109b36c04371cd3f479a4594208c8", "native"),
}
commits = {
    "baseline": "bec47abba980d48432c8b5917ca682dd0a5758de",
    "candidate": "32fdd92c880a8fc1341e37e604c8a568ef558ebb",
}
fields = {
    "short_ttft_ms": ("short", "ttft_ms"),
    "short_solo_ttft_ms": ("short_solo", "ttft_ms"),
    "long_total_ms": ("long", "total_ms"),
    "long_solo_total_ms": ("long_solo", "total_ms"),
}
method = hashlib.sha256(
    (root / "benchmark_default_prefill.py").read_bytes()
).hexdigest()
assert method == "7ff73a02c9c3b790a70d127cbbf996dfa8d24592e5b6b6d3be155313392d34e7"
for cell, (revision, lane) in cases.items():
    path = root / cell / "default-routes-final"
    d = json.loads((path / "results.json").read_text())
    assert d.get("complete") and len(d["arms"]) == 4 and len(d["rows"]) == 8
    assert d["harness_sha256"] == d["_methodology_hash"] == method
    assert d["model_revision"] == revision and d["repeat"] == d["cycles"] == 2
    assert [(a["label"], a["source_commit"]) for a in d["arms"]] == [
        (f"cycle{cycle}-{kind}2048", commits[kind])
        for cycle in (0, 1)
        for kind in (
            ("baseline", "candidate") if cycle == 0 else ("candidate", "baseline")
        )
    ]
    assert {(r["arm"], r["cycle"], r["repeat"]) for r in d["rows"]} == {
        (kind + "2048", cycle, repeat)
        for kind in commits
        for cycle in (0, 1)
        for repeat in (0, 1)
    }
    expected_packages = {
        "mlx": "0.32.3",
        "mlx-lm": "0.31.3",
        "mlx-vlm": "0.7.2",
        "transformers": "5.15.1",
        "numpy": "2.4.4",
        "httpx": "0.28.1",
    }
    assert d["packages"] == expected_packages
    assert (
        len({arm["source_sha256"]["rapid_mlx/scheduler.py"] for arm in d["arms"]}) == 1
    )
    for arm in d["arms"]:
        assert arm["exit_code"] in (0, -15)
        assert (
            arm["final_status"]["num_running"]
            == arm["final_status"]["num_waiting"]
            == 0
        )
        for name, expected in arm["source_sha256"].items():
            raw = subprocess.check_output(
                ["git", "show", arm["source_commit"] + ":" + name]
            )
            assert hashlib.sha256(raw).hexdigest() == expected
        rows = [
            json.loads(line)
            for line in (path / (arm["label"] + ".trace.jsonl"))
            .read_text()
            .splitlines()
        ]
        assert rows and all(t["ended_ns"] >= t["started_ns"] for t in rows)
        assert not any(t.get("cooperative") or t.get("suspended") for t in rows)
        if lane == "mllm":
            assert any(t.get("lane") == "mllm" for t in rows)
            assert not any(t.get("lane") != "mllm" for t in rows)
        else:
            assert all(t.get("lane") != "mllm" for t in rows)
        assert all(
            0 < t["dispatched"] <= t["selected"]
            for t in rows
            if t.get("lane") != "mllm"
        )
    for row in d["rows"]:
        validate_overlap(row["long"], row["short"])
        for which in ("long_solo", "long", "short_solo", "short"):
            r = row[which]
            validate_cold(r, "7319" if which.startswith("long") else "9283")
            assert r["done"] and r["finish_reason"] == "stop"
            assert r["started_ns"] < r["first_ns"] <= r["ended_ns"]
            assert (
                hashlib.sha256(r["output_text"].encode()).hexdigest()
                == r["output_sha256"]
            )
            assert 0 < r["usage"]["completion_tokens"] <= 32
            assert (
                r["usage"]["total_tokens"]
                == r["usage"]["prompt_tokens"] + r["usage"]["completion_tokens"]
            )
    for kind in commits:
        raw = {
            key: statistics.median(
                row[which][metric] for row in d["rows"] if row["arm"] == kind + "2048"
            )
            for key, (which, metric) in fields.items()
        }
        assert raw == d["summary"][kind + "2048"]["retrieval"]
    print(
        cell,
        "passed: source/method/snapshot/cardinality, actual disabled activation and lane, exact HTTP receipts, raw medians; no accelerated-path/lifecycle claim",
    )
models = json.loads((root / "family-model-manifest.json").read_text())
gold = json.loads((root / "family-lfs-digests.json").read_text())
assert models["0d77464eeb233a2da68ebf9d7dc4edaac7db956d"]["model_type"] == "gemma4"
assert models["55ac8c89261109b36c04371cd3f479a4594208c8"]["model_type"] == "nemotron_h"
for revision, entries in gold.items():
    for name, expected in entries.items():
        assert models[revision]["files"][name]["sha256"] == expected
print(
    "Model configurations and all seven weight-shard hashes match cached upstream digests"
)
manifest = root / "manifest.json"
if manifest.exists():
    for name, entry in json.loads(manifest.read_text()).items():
        raw = (root / name).read_bytes()
        assert (
            len(raw) == entry["bytes"]
            and hashlib.sha256(raw).hexdigest() == entry["sha256"]
        ), name
    print("All inner artifact hashes passed")
