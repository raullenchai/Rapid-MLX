"""Check the preregistered source/model/method contract of one HTTP matrix cell."""

import json
import re
import sys
from pathlib import Path

p = Path(sys.argv[1])
step = int(sys.argv[2])
revision = sys.argv[3]
mode = sys.argv[4]
d = json.loads(p.read_text())
assert d.get("complete") and len(d["rows"]) == 8 and len(d["arms"]) == 4
assert (
    d["harness_sha256"]
    == d["_methodology_hash"]
    == "7ff73a02c9c3b790a70d127cbbf996dfa8d24592e5b6b6d3be155313392d34e7"
)
assert d["model_revision"] == revision and d["repeat"] == d["cycles"] == 2
expected = {
    "baseline": "bec47abba980d48432c8b5917ca682dd0a5758de",
    "candidate": "32fdd92c880a8fc1341e37e604c8a568ef558ebb",
}
assert [(a["label"], a["source_commit"]) for a in d["arms"]] == [
    (f"cycle{cycle}-{kind}{step}", expected[kind])
    for cycle in (0, 1)
    for kind in (("baseline", "candidate") if cycle == 0 else ("candidate", "baseline"))
]
assert {(r["arm"], r["cycle"], r["repeat"]) for r in d["rows"]} == {
    (f"{kind}{step}", cycle, repeat)
    for kind in expected
    for cycle in (0, 1)
    for repeat in (0, 1)
}
assert (
    d["packages"]["mlx"] == "0.32.3"
    and d["packages"]["mlx-lm"] == "0.31.3"
    and d["packages"]["mlx-vlm"] == "0.7.2"
    and d["packages"]["transformers"] == "5.15.1"
)
for arm in d["arms"]:
    if mode == "dense":
        log = (p.parent / (arm["label"] + ".server.log")).read_text()
        startup = next(
            line
            for line in log.splitlines()
            if "MLLM Scheduler started with continuous batching:" in line
        )
        effective = int(re.search(r"prefill_step_size=(\d+)", startup).group(1))
        assert min(effective, 2048) == step, (arm["label"], effective, step)
    trace = [
        json.loads(line)
        for line in (p.parent / (arm["label"] + ".trace.jsonl"))
        .read_text()
        .splitlines()
    ]
    candidate = "candidate" in arm["label"]
    if mode == "native":
        assert not any(t.get("cooperative") or t.get("suspended") for t in trace)
    elif candidate:
        assert any(t.get("suspended") for t in trace)
        assert all(t["cooperative"] for t in trace if t.get("lane") == "mllm")
    else:
        assert not any(t.get("cooperative") or t.get("suspended") for t in trace)
for row in d["rows"]:
    if mode == "dense" and row["arm"].startswith("candidate"):
        assert row["short"]["first_ns"] < row["long"]["first_ns"]
        trace = [
            json.loads(line)
            for line in (p.parent / f"cycle{row['cycle']}-{row['arm']}.trace.jsonl")
            .read_text()
            .splitlines()
        ]
        assert any(
            t.get("lane") != "mllm"
            and row["short"]["started_ns"] <= t["started_ns"] < row["long"]["first_ns"]
            for t in trace
        )
print(
    "Intended commits, model snapshot, chunk size, four children/eight waves, packages, methodology and route activation checks passed"
)
base = d["summary"][f"baseline{step}"][d["workloads"][0]]
candidate = d["summary"][f"candidate{step}"][d["workloads"][0]]
print(
    json.dumps(
        {
            k: {
                "baseline_ms": base[k],
                "candidate_ms": v,
                "change_percent": (v / base[k] - 1) * 100,
            }
            for k, v in candidate.items()
        },
        indent=2,
    )
)
