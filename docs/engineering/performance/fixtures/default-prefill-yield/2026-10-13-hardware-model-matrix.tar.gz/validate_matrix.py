"""Validate every registered complete cell in the archived hardware matrix."""

import hashlib
import json
import statistics
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent
cells = json.loads((root / "cells.json").read_text())
assert len({c["path"] for c in cells}) == len(cells)
for cell in cells:
    result = root / cell["path"] / "default-routes-final/results.json"
    args = [sys.executable, str(root / "validate_matrix_cell.py"), str(result), "8"]
    if cell["mode"] == "native":
        args += ["--off-path", "--skip-lifecycle"]
    subprocess.run(args, check=True)
    subprocess.run(
        [
            sys.executable,
            str(root / "validate_matrix_binding.py"),
            str(result),
            str(cell["text_chunk_tokens"]),
            cell["model_revision"],
            cell["mode"],
        ],
        check=True,
    )
    d = json.loads(result.read_text())
    step = cell["text_chunk_tokens"]
    a = d["summary"][f"baseline{step}"]["retrieval"]
    b = d["summary"][f"candidate{step}"]["retrieval"]
    fields = {
        "short_ttft_ms": ("short", "ttft_ms"),
        "short_solo_ttft_ms": ("short_solo", "ttft_ms"),
        "long_total_ms": ("long", "total_ms"),
        "long_solo_total_ms": ("long_solo", "total_ms"),
    }
    for kind, summary in (("baseline", a), ("candidate", b)):
        raw = {
            key: statistics.median(
                row[which][metric]
                for row in d["rows"]
                if row["arm"] == f"{kind}{step}" and row["workload"] == "retrieval"
            )
            for key, (which, metric) in fields.items()
        }
        assert raw == summary, (cell["path"], kind, raw, summary)
    assert a == cell["medians_baseline_ms"] and b == cell["medians_candidate_ms"]
    delta = {k: (b[k] / a[k] - 1) * 100 for k in b}
    assert delta == cell["descriptive_change_percent"]
    if cell["mode"] == "dense":
        life = json.loads(
            (root / cell["path"] / "http-lifecycle-paused/results.json").read_text()
        )
        assert (
            life["model_revision"] == cell["model_revision"]
            and life["source_commit"] == "32fdd92c880a8fc1341e37e604c8a568ef558ebb"
        )
        assert cell["performance_gate_passed"] == (
            delta["short_ttft_ms"] <= -30
            and max(v for k, v in delta.items() if k != "short_ttft_ms") <= 10
        )
        source = root / (
            "check_http_lifecycle_2048.py"
            if step == 2048
            else "check_http_lifecycle.py"
        )
        assert source.exists() and ('"' + str(step) + '",') in source.read_text()
    else:
        assert cell["performance_gate_passed"] is None
# The same snapshot must be the same weights/tokenizer on both primary hosts.
a = json.loads((root / "m4/model-manifest.json").read_text())
b = json.loads((root / "m5/model-manifest.json").read_text())
assert (
    a["32f3e8ecf65426fc3306969496342d504bfa13f3"]
    == b["32f3e8ecf65426fc3306969496342d504bfa13f3"]
)
manifest = root / "manifest.json"
if manifest.exists():
    for name, row in json.loads(manifest.read_text()).items():
        data = (root / name).read_bytes()
        assert (
            hashlib.sha256(data).hexdigest() == row["sha256"]
            and len(data) == row["bytes"]
        ), name
print(
    f"{len(cells)} complete cells validated; per-cell gates/route eligibility and all artifact hashes verified"
)
